data:extend(
{
  {
    type = "recipe",
    name = "iron-briquette",
    enabled = false,
    category = "crafting-with-fluid",
    ingredients = {
      { type = "item", name = "iron-dust", amount = 50 }
    },
    results = {
      { type = "item", name = "iron-briquette", amount = 1 },
    },
    energy_required = 10,
  },
})
