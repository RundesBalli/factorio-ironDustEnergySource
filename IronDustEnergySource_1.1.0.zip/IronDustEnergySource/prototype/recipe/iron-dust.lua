data:extend(
{
  {
    type = "recipe",
    name = "iron-dust",
    enabled = false,
    category = "crafting-with-fluid",
    ingredients = {
      { type = "item", name = "iron-ore", amount = 5 }
    },
    results = {
      { type = "item", name = "iron-dust", amount = 1 },
    },
    energy_required = 2,
  },
})
